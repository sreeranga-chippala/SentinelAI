"""
models/area.py
"""

from dataclasses import dataclass


@dataclass(slots=True)
class Area:

    area_id: str

    name: str

    population: int

    children: int

    adults: int

    elderly: int

    disabled: int

    rescue_requests: int

    latitude: float

    longitude: float