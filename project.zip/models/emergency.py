"""
Emergency Event Model
"""

from dataclasses import dataclass


@dataclass(slots=True)
class Emergency:

    event_id: str

    event_type: str

    area_id: str

    severity: str

    timestamp: str

    status: str = "ACTIVE"