"""
Hospital Model
"""

from dataclasses import dataclass


@dataclass(slots=True)
class Hospital:

    hospital_id: str

    name: str

    latitude: float

    longitude: float

    total_beds: int

    available_beds: int

    icu_beds: int

    emergency_capacity: int

    occupied: bool = False