"""
models/hospital_status.py

Represents the current operational status of a hospital.
"""

from dataclasses import dataclass


@dataclass(slots=True)
class HospitalStatus:

    hospital_id: str

    hospital_name: str

    total_beds: int

    available_beds: int

    occupied_beds: int

    occupancy_percentage: float

    icu_beds: int

    emergency_capacity: int

    status: str