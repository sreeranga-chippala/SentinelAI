"""
models/population_assessment.py

Represents the vulnerability assessment of an area's population.
"""

from dataclasses import dataclass


@dataclass(slots=True)
class PopulationAssessment:

    area: str

    total_population: int

    children: int

    adults: int

    elderly: int

    disabled: int

    rescue_requests: int

    vulnerability_score: int

    priority_level: str

    reason: str