"""
utils/hospital_analyzer.py
"""

from models.hospital_status import HospitalStatus


class HospitalAnalyzer:

    @staticmethod
    def analyze(hospital):

        occupied = hospital.total_beds - hospital.available_beds

        occupancy = (
            occupied / hospital.total_beds
        ) * 100

        if occupancy >= 95:
            status = "Full"

        elif occupancy >= 80:
            status = "Critical"

        elif occupancy >= 60:
            status = "Busy"

        else:
            status = "Available"

        return HospitalStatus(
            hospital_id=hospital.hospital_id,
            hospital_name=hospital.name,
            total_beds=hospital.total_beds,
            available_beds=hospital.available_beds,
            occupied_beds=occupied,
            occupancy_percentage=round(
                occupancy,
                2
            ),
            icu_beds=hospital.icu_beds,
            emergency_capacity=hospital.emergency_capacity,
            status=status,
        )